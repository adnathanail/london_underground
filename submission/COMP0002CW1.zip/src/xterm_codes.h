//
// Created by Alexander Nathanail on 10/11/2020.
//

#ifndef LONDON_UNDERGROUND_XTERM_CODES_H
#define LONDON_UNDERGROUND_XTERM_CODES_H

#define XT_RSET "\x1B[0m"
#define XT_BOLD "\x1B[1m"
#define XT_UNDL "\x1B[4m"

#endif //LONDON_UNDERGROUND_XTERM_CODES_H
