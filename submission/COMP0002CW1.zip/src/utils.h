//
// Created by Alexander Nathanail on 10/11/2020.
//

#ifndef LONDON_UNDERGROUND_UTILS_H
#define LONDON_UNDERGROUND_UTILS_H

void str_tolower(char* s);

#endif //LONDON_UNDERGROUND_UTILS_H
